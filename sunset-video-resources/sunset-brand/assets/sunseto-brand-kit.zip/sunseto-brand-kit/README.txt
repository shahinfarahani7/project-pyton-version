Sunseto brand kit, edition 01 (September 2026)

Logo, mark, seal and icon, ornaments, stamps, engravings, 3D tiles and textures: Sunseto. Use them for Sunseto only.
Fonts: SIL Open Font License 1.1, licences in fonts/licenses. Instrument Sans and Serif by Instrument; JetBrains Mono by JetBrains;
Shippori Mincho by FONTDASU (cut to the kanji the site uses).
Source: the scripts that draw the mark, render the enamel version, lay out the lockups and cut the fonts.
